## 0.0.1
- Initial release of `flutter_toggle_button` package.
- Added `FlutterToggleButton` widget.
- Support for customizable button width, height, and border radius.
- Support for both solid colors and gradients for buttons and outer container.
- Text customization with font size, weight, and color for enabled and disabled states.
- Callback support for button taps.
- Flexible item types, supporting String, int, double, and Widget.